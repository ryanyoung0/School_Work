from hardware import Memory, RegisterFile, Register, MUX_2_1, ALU_32, AND_2
import utilities
from signals import Signals
# Ryan Young Lab 8
class Core_SC:
    def __init__(self):
        self.I_Mem = Memory()
        self.D_Mem = Memory()
        self.RF = RegisterFile()
        self.RegPC = Register()
        self.signals = Signals()
        self.cycle_num = 0
        self.mode = 0

    def set_PC(self, pc):
        self.RegPC.set_data(pc)
        self.RegPC.set_write(1)

    def set_mode(self, mode):
        self.mode = mode

    def run(self, n_cycles):
        i_cycles = 0
        ending_PC = self.I_Mem.get_ending_address()

        self.I_Mem.set_memread(1)
        self.I_Mem.set_memwrite(0)

        while (n_cycles == 0 or i_cycles < n_cycles):
            i_cycles += 1
            self.cycle_num += 1
            if ((self.mode & 2) == 0): utilities.print_new_cycle(self.cycle_num)

            # clock changes
            self.RegPC.clock()
            self.RF.clock()

            # read PC
            self.signals.PC = self.RegPC.read()
            self.signals.PC_4 = self.signals.PC_new = self.signals.PC + 4
            if ((self.mode & 2) == 0): utilities.println_int("PC", self.signals.PC)
            if (self.signals.PC > ending_PC):
                if ((self.mode & 2) == 0): print("No More Instructions")
                i_cycles -= 1
                break

            self.I_Mem.set_address(self.signals.PC)
            self.I_Mem.run()
            self.signals.instruction = self.I_Mem.get_data()

            if ((self.mode & 2) == 0): utilities.println_int("instruction", self.signals.instruction)

            # Now you have PC and the instruction
            # Some signals' value can be extracted from instruction directly
            self.signals_from_instruction(self.signals.instruction, self.signals)

            # call main_control
            self.main_control(self.signals.opcode, self.signals)

            # call sign_extend
            self.signals.Sign_extended_immediate = self.sign_extend(self.signals.immediate)

            # Write_register. Also an example of using MUX
            self.signals.Write_register = MUX_2_1(self.signals.rt, self.signals.rd, self.signals.RegDst)

            # ALU control
            self.signals.ALU_operation = self.ALU_control(self.signals.ALUOp, self.signals.funct)

            # Calculate branch address
            self.signals.Branch_address = self.calculate_branch_address(self.signals.PC_4, self.signals.Sign_extended_immediate)
            self.signals.Jump_address = self.calculate_jump_address(self.signals.PC_4, self.signals.instruction)

            # Print out signals generated in Phase 1.
            if ((self.mode & 4) == 0): utilities.print_signals_1(self.signals)

            # If phase 1 only, continue to the next instruction.
            if ((self.mode & 1) != 0):
                self.RegPC.set_data(self.signals.PC_4)
                self.RegPC.set_write(1)
                continue
            # You will continue to complete the core in phase 2
            # Use RF, ALU, D_Mem
        #    self.RF.set_read_registers(self.signals.rs, self.signals.rt)
        #    self.RF.read_data_1 = self.RF.get_read_data_1()
        #    self.signals.ALU_input_2 = MUX_2_1(self.RF.read_data_2, self.Sign_extended_immediate, sig.ALUSrc)
        #    self.ALU_result = self.ALU_returned_value[0]
        #    self.Zero = self.ALU_returned_value[1]

            # Compute PC_new
        ##    self.RegPC.set_write(1)

            # get the registers their data
            self.RF.set_read_registers(self.signals.rs, self.signals.rt)
            self.signals.RF_read_data_1 = self.RF.get_read_data_1()
            self.signals.RF_read_data_2 = self.RF.get_read_data_2()
            # get the alu input form the mux
            self.signals.ALU_input_2 = MUX_2_1(self.signals.RF_read_data_2, self.signals.Sign_extended_immediate, self.signals.ALUSrc)
            # Dina when we changed it to signal self.singals.operation it would not work and had way too many cycles so i changed it back and now matches the output
            self.signals.ALU_returned_value = ALU_32(self.signals.RF_read_data_1, self.signals.ALU_input_2, self.ALU_control(self.signals.ALUOp, self.signals.funct))
            # get the result from the ALU
            self.signals.ALU_result = self.signals.ALU_returned_value[0]
            self.signals.Zero = self.signals.ALU_returned_value[1]
            # set the Mem address and write the data
            self.D_Mem.set_data(self.signals.RF_read_data_2)
            self.D_Mem.set_address(self.signals.ALU_result)
            # Check if we need to read or write from mem
            self.D_Mem.set_memread(self.signals.MemRead)
            self.D_Mem.set_memwrite(self.signals.MemWrite)
            #need to run
            self.D_Mem.run()
            #get the data
            self.signals.MEM_read_data = self.D_Mem.get_data()
            self.signals.Write_data = MUX_2_1(self.signals.ALU_result, self.signals.MEM_read_data, self.signals.MemtoReg)
            # set the write register and signals
            self.RF.set_write_data(self.signals.Write_data)
            self.RF.set_write_register(self.signals.Write_register)
            self.RF.set_regwrite(self.signals.RegWrite)
            # calc branch new pc and pcsrc
            self.signals.PCSrc = AND_2(self.signals.Branch, self.signals.Zero)
            self.signals.PC_branch = MUX_2_1(self.signals.PC_4, self.signals.Branch_address, self.signals.PCSrc)
            self.signals.PC_new = MUX_2_1(self.signals.PC_branch, self.signals.Jump_address, self.signals.Jump)
            # set the data
            self.RegPC.set_write(1)
            self.RegPC.set_data(self.signals.PC_new)

            # Print out signals generated in Phase 2.
            if ((self.mode & 8) == 0): utilities.print_signals_2(self.signals)
        return i_cycles

    def signals_from_instruction (self, instruction, sig):
        """
        Extract the following signals from instruction.
            opcode, rs, rt, rd, funct, immediate
        """
        sig.opcode = (instruction >> 26) & 0x3F # getting the opcode from from instruction aka first 6 btis
        sig.rs = (instruction >> 21) & 0x1F # getting register rs from instruction aka next 5 bits
        sig.rt = (instruction >> 16) & 0x1F # getting regsiter rt from instruction aka next 5 bits
        sig.rd = (instruction >> 11) & 0x1F # gettting register rd from instruction aka next 5 bits
        sig.shamt = (instruction >> 6) & 0x1F # getting shamt (the shift needed from instruction) aka next 5 bits
        sig.funct = instruction & 0x3F # getting the funct from the instruction the last 6 bits
        sig.immediate = instruction & 0xFFFF # getting the imeddiate from the instruction
    def main_control(self, opcode, sig):
        """
        Check the type of input instruction
        """
        #set defaults for control signals
        sig.RegDst = sig.Jump = sig.Branch = sig.MemRead = sig.MemtoReg = sig.ALUOp = sig.MemWrite = sig.ALUSrc = sig.RegWrite = 0

        #determine control signals
        if opcode == 0:             # R-Type 000000
            sig.RegWrite = 1 # we are writing to a register
            sig.RegDst = 1
            sig.ALUOp = 2
        # opcode for jump
        elif opcode == 2:
            sig.Jump = 1 # only opcode that will affect jump
        # opcode for branch
        elif opcode == 4:
            sig.Branch = 1 # only opcode that will affect branch
            sig.ALUOp = 1
        # opcode for addi
        elif opcode == 8:
            sig.RegWrite = 1 # we are writing to a register
            sig.ALUOp = 0
            sig.ALUSrc = 1
        # opcode for load word
        elif opcode == 35:
            sig.RegWrite = 1 # we are writing to a register
            sig.MemRead = 1 # we are reading fom memory
            sig.MemtoReg = 1 # we are going from memory to register
            sig.ALUSrc = 1
            sig.ALUOp = 0
        # opcode for save word
        elif opcode == 43:
            sig.ALUSrc = 1
            sig.MemWrite = 1 # we are writing to memory
            sig.ALUOp = 0
        else:
            raise ValueError("Unknown opcode 0x%02X" % opcode)
        return
    def ALU_control(self, alu_op, funct):
        """
        Get alu_control from func field of instruction
        Input: function field of instruction
        Output: alu_control_out

        """
        alu_control_out = 0
        # One example is given, continue to finish other cases.
        if alu_op == 0:             # 00
            alu_control_out = 2     # 0010
        elif alu_op == 1: # checking the 2 digit
            alu_control_out = 6 # setting the four digit
        elif alu_op == 2:
            if funct == 32:
                alu_control_out = 2
            elif funct == 34:
                alu_control_out = 6
            elif funct == 36:
                alu_control_out = 0
            elif funct == 37:
                alu_control_out = 1
            elif funct == 42:
                alu_control_out = 7
        else:
            raise ValueError("Unknown opcode code 0x%02X" % alu_op)
        return alu_control_out

    def sign_extend(self, immd):
        """
        Sign extend module.
        Convert 16-bit to an int.
        Extract the lower 16 bits.
        If bit 15 of immd is 1, compute the correct negative value (immd - 0x10000).
        """
        immd = immd & 0xFFFF # first half of it
        if immd & 0x8000: # check the second half to see if it is negatibe
            immd -= 0x10000 # subtracting like it says to
        return immd

    def calculate_branch_address(self, pc_4, extended):
        addr = pc_4 + (extended << 2) # new address is the immediate shifted left twice and plus the pc+4
        return addr

    def calculate_jump_address(self, pc_4, instruction):
        new_instruction = instruction & 0x3FFFFFF # this is now the jump immediate
        new_pc_4 = pc_4 & 0xF0000000 # getting the first four bits from the next line
        addr = new_pc_4 + (new_instruction << 2) # need to shift left twice to convert to word
        return addr
#core = Core_SC()
#core.run(2000)
